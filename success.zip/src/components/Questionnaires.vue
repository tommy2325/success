<template>
  <div>
    <header>
      <h1>Gestion des Questionnaires</h1>
    </header>

    <div v-if="showEditForm">
      <div>
        <label>Nom:</label>
        <input v-model="questionnaire.nom" type="text" />
      </div>
      <div>
        <label>Temps de passage:</label>
        <input v-model="questionnaire.temps_de_passage" type="number" />
      </div>
      <div>
        <label>Code:</label>
        <input v-model="questionnaire.code" type="text" />
      </div>
      <button @click="updateQuestionnaire">Enregistrer</button>
      <button @click="editQuestions">Modifier les Questions</button>
      <button @click="hideEditForm">Annuler</button>
    </div>

    <div>
      <input 
        v-model="searchQuery" 
        type="text" 
        placeholder="Rechercher par nom..."
        @input="filterQuestionnaires"
      />
    </div>

    <table v-if="!showCreation && !showEditForm" class="data-table">
      <thead>
        <tr>
          <th>
            <input type="checkbox" v-model="selectAll" @change="toggleSelectAll" />
          </th>
          <th>Nom</th>
          <th>Date de création</th>
          <th>Temps</th>
          <th>Code</th>
          <th>Options</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(questionnaire, index) in filteredQuestionnaires" :key="questionnaire.id_questionnaire">
          <td>
            <input 
              type="checkbox" 
              :checked="selectedQuestionnaires.includes(questionnaire.id_questionnaire)"
              @change="toggleQuestionnaireSelection(questionnaire.id_questionnaire)"
            />
          </td>
          <td>{{ questionnaire.nom }}</td>
          <td>{{ questionnaire.date_creation }}</td>
          <td>{{ questionnaire.temps_de_passage }} minutes</td>
          <td>{{ questionnaire.code }}</td>
          <td>
            <button @click="editQuestionnaire(questionnaire.id_questionnaire)">Modifier</button>
            <button @click="deleteQuestionnaire(questionnaire.id_questionnaire)">Supprimer</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { supabase } from '../supabase';

const router = useRouter();
const questionnaires = ref([]);
const filteredQuestionnaires = ref([]);
const showCreation = ref(false);
const showEditForm = ref(false);
const selectAll = ref(false);
const selectedQuestionnaires = ref([]);
const searchQuery = ref('');
const questionnaire = ref({});

const fetchQuestionnaires = async () => {
  const { data, error } = await supabase.from('questionnaire').select('*');
  if (error) {
    console.error('Erreur lors de la récupération des questionnaires:', error);
  } else {
    questionnaires.value = data;
    filteredQuestionnaires.value = data; // Initialisation avec tous les questionnaires
  }
};

const showCreationForm = () => {
  showCreation.value = true;
};

const hideCreationForm = () => {
  showCreation.value = false;
};

const hideEditForm = () => {
  showEditForm.value = false;
};

const editQuestionnaire = async (questionnaireId) => {
  const { data, error } = await supabase
    .from('questionnaire')
    .select('*')
    .eq('id_questionnaire', questionnaireId)
    .single();

  if (error) {
    console.error('Erreur lors de la récupération du questionnaire:', error);
    return;
  }

  questionnaire.value = data;
  showEditForm.value = true;
};

const updateQuestionnaire = async () => {
  const { error } = await supabase
    .from('questionnaire')
    .update({
      nom: questionnaire.value.nom,
      temps_de_passage: questionnaire.value.temps_de_passage,
      code: questionnaire.value.code,
    })
    .eq('id_questionnaire', questionnaire.value.id_questionnaire);

  if (error) {
    console.error('Erreur lors de la mise à jour du questionnaire:', error);
  } else {
    showEditForm.value = false;
    fetchQuestionnaires();
  }
};

const editQuestions = () => {
  router.push({ name: 'EditQuestions', params: { questionnaireId: questionnaire.value.id_questionnaire } });
};

const deleteQuestionnaire = async (questionnaireId) => {
  const { error } = await supabase
    .from('questionnaire')
    .delete()
    .eq('id_questionnaire', questionnaireId);

  if (error) {
    console.error('Erreur lors de la suppression du questionnaire:', error);
  } else {
    fetchQuestionnaires();
  }
};

const toggleSelectAll = () => {
  if (selectAll.value) {
    selectedQuestionnaires.value = questionnaires.value.map((q) => q.id_questionnaire);
  } else {
    selectedQuestionnaires.value = [];
  }
};

const toggleQuestionnaireSelection = (id) => {
  if (selectedQuestionnaires.value.includes(id)) {
    selectedQuestionnaires.value = selectedQuestionnaires.value.filter((qid) => qid !== id);
  } else {
    selectedQuestionnaires.value.push(id);
  }
  selectAll.value = questionnaires.value.length === selectedQuestionnaires.value.length;
};

// Fonction de filtrage des questionnaires
const filterQuestionnaires = () => {
  filteredQuestionnaires.value = questionnaires.value.filter((questionnaire) => 
    questionnaire.nom.toLowerCase().includes(searchQuery.value.toLowerCase())
  );
};

onMounted(() => {
  fetchQuestionnaires();
});
</script>

<style scoped>
header {
  background-color: #c59edb;
  color: white;
  padding: 20px;
  text-align: center;
}

button {
  background-color: #c59edb;
  border: none;
  padding: 10px;
  color: white;
  font-size: 1rem;
  border-radius: 5px;
  cursor: pointer;
  margin-top: 10px;
}

button:hover {
  background-color: #b48ac6;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

table th, table td {
  border: 1px solid #ccc;
  padding: 10px;
  text-align: left;
}

.data-table th {
  background-color: #f0f0f0;
}

.data-table tr:nth-child(even) {
  background-color: #f9f9f9;
}

input[type="text"] {
  padding: 10px;
  margin-top: 10px;
  width: 200px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
</style>
